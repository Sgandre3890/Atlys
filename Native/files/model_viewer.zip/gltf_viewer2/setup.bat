@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo  Model Viewer - Windows Setup
echo ============================================================
echo.

:: ── Check for required tools ─────────────────────────────────────────────────

where cmake >nul 2>&1
if errorlevel 1 (
    echo [ERROR] CMake not found. Install from: https://cmake.org/download/
    echo         Tick "Add CMake to PATH" during install.
    pause & exit /b 1
)
echo [OK] CMake found: 
cmake --version | findstr /i "cmake version"

where git >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Git not found. Install from: https://git-scm.com/download/win
    pause & exit /b 1
)
echo [OK] Git found

:: Check for a C++ compiler (Visual Studio or Build Tools)
where cl >nul 2>&1
if errorlevel 1 (
    echo.
    echo [WARNING] MSVC compiler ^(cl.exe^) not found in PATH.
    echo   This usually means you need to run this script from a
    echo   "Developer Command Prompt for VS" or install:
    echo   https://visualstudio.microsoft.com/visual-cpp-build-tools/
    echo   Install "Desktop development with C++" workload.
    echo.
    echo   Trying to continue anyway in case another compiler is available...
    echo.
)

:: ── vcpkg setup ───────────────────────────────────────────────────────────────

set VCPKG_DIR=%USERPROFILE%\vcpkg

if not exist "%VCPKG_DIR%\vcpkg.exe" (
    echo [INFO] Cloning vcpkg...
    git clone https://github.com/microsoft/vcpkg.git "%VCPKG_DIR%"
    if errorlevel 1 (
        echo [ERROR] Failed to clone vcpkg. Check your internet connection.
        pause & exit /b 1
    )
    echo [INFO] Bootstrapping vcpkg...
    call "%VCPKG_DIR%\bootstrap-vcpkg.bat" -disableMetrics
    if errorlevel 1 (
        echo [ERROR] vcpkg bootstrap failed.
        pause & exit /b 1
    )
)
echo [OK] vcpkg ready at %VCPKG_DIR%

:: ── Install dependencies one at a time for clearer error messages ─────────────

echo.
echo [INFO] Installing glfw3 (window/input library)...
"%VCPKG_DIR%\vcpkg.exe" install glfw3:x64-windows
if errorlevel 1 (
    echo [ERROR] Failed to install glfw3.
    echo   Try running this from a Developer Command Prompt for VS.
    pause & exit /b 1
)
echo [OK] glfw3 installed

echo [INFO] Installing glm (math library)...
"%VCPKG_DIR%\vcpkg.exe" install glm:x64-windows
if errorlevel 1 (
    echo [ERROR] Failed to install glm.
    pause & exit /b 1
)
echo [OK] glm installed

echo [INFO] Installing assimp (model loader - this one takes a while)...
"%VCPKG_DIR%\vcpkg.exe" install assimp:x64-windows
if errorlevel 1 (
    echo [ERROR] Failed to install assimp.
    echo   This can fail if MSVC build tools aren't installed.
    echo   Install from: https://visualstudio.microsoft.com/visual-cpp-build-tools/
    echo   Select "Desktop development with C++" workload.
    pause & exit /b 1
)
echo [OK] assimp installed

:: ── stb_image ─────────────────────────────────────────────────────────────────

if not exist "stb_image.h" (
    echo.
    echo [INFO] Downloading stb_image.h...
    curl -sL "https://raw.githubusercontent.com/nothings/stb/master/stb_image.h" -o stb_image.h
    if errorlevel 1 (
        echo [ERROR] Failed to download stb_image.h. Check your internet connection.
        pause & exit /b 1
    )
    echo [OK] stb_image.h downloaded
)

:: ── Build ─────────────────────────────────────────────────────────────────────

echo.
echo [INFO] Configuring CMake...
if exist build rmdir /s /q build
mkdir build

cmake -S . -B build ^
    -DCMAKE_BUILD_TYPE=Release ^
    -DCMAKE_TOOLCHAIN_FILE="%VCPKG_DIR%\scripts\buildsystems\vcpkg.cmake" ^
    -DVCPKG_TARGET_TRIPLET=x64-windows

if errorlevel 1 (
    echo.
    echo [ERROR] CMake configure failed. Common causes:
    echo   - No C++ compiler found. Install Visual Studio Build Tools.
    echo   - Run this from a Developer Command Prompt for VS.
    pause & exit /b 1
)

echo.
echo [INFO] Building (this may take a minute)...
cmake --build build --config Release
if errorlevel 1 (
    echo.
    echo [ERROR] Build failed. Check the output above for details.
    pause & exit /b 1
)

echo.
echo ============================================================
echo  Success! Run model_viewer.exe to start.
echo ============================================================
pause
