@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo  Model Viewer - Windows Setup
echo ============================================================
echo.

:: ── Check for required tools ─────────────────────────────────────────────────

where cmake >nul 2>&1
if errorlevel 1 (
    echo [ERROR] CMake not found.
    echo   Download and install it from: https://cmake.org/download/
    echo   Make sure to tick "Add CMake to PATH" during install.
    pause & exit /b 1
)

where git >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Git not found.
    echo   Download and install it from: https://git-scm.com/download/win
    pause & exit /b 1
)

:: ── Check for vcpkg ───────────────────────────────────────────────────────────
:: vcpkg is the easiest way to get glfw, assimp, and glm on Windows.

set VCPKG_DIR=%USERPROFILE%\vcpkg

if not exist "%VCPKG_DIR%\vcpkg.exe" (
    echo [INFO] vcpkg not found. Cloning and bootstrapping...
    git clone https://github.com/microsoft/vcpkg.git "%VCPKG_DIR%"
    if errorlevel 1 ( echo [ERROR] Failed to clone vcpkg. & pause & exit /b 1 )
    call "%VCPKG_DIR%\bootstrap-vcpkg.bat" -disableMetrics
    if errorlevel 1 ( echo [ERROR] vcpkg bootstrap failed. & pause & exit /b 1 )
    echo [OK] vcpkg installed.
) else (
    echo [OK] vcpkg found at %VCPKG_DIR%
)

:: ── Install dependencies via vcpkg ────────────────────────────────────────────

echo.
echo [INFO] Installing dependencies (this may take a few minutes the first time)...
"%VCPKG_DIR%\vcpkg.exe" install glfw3:x64-windows assimp:x64-windows glm:x64-windows
if errorlevel 1 ( echo [ERROR] vcpkg install failed. & pause & exit /b 1 )
echo [OK] Dependencies installed.

:: ── Download stb_image ────────────────────────────────────────────────────────

if not exist "stb_image.h" (
    echo.
    echo [INFO] Downloading stb_image.h...
    curl -sL "https://raw.githubusercontent.com/nothings/stb/master/stb_image.h" -o stb_image.h
    if errorlevel 1 ( echo [ERROR] Failed to download stb_image.h & pause & exit /b 1 )
    echo [OK] stb_image.h downloaded.
)

:: ── Build ─────────────────────────────────────────────────────────────────────

echo.
echo [INFO] Configuring with CMake...
if exist build rmdir /s /q build
mkdir build
cmake -S . -B build ^
    -DCMAKE_BUILD_TYPE=Release ^
    -DCMAKE_TOOLCHAIN_FILE="%VCPKG_DIR%\scripts\buildsystems\vcpkg.cmake" ^
    -DVCPKG_TARGET_TRIPLET=x64-windows
if errorlevel 1 ( echo [ERROR] CMake configure failed. & pause & exit /b 1 )

echo.
echo [INFO] Building...
cmake --build build --config Release
if errorlevel 1 ( echo [ERROR] Build failed. & pause & exit /b 1 )

echo.
echo ============================================================
echo  Build complete!  Run:  model_viewer.exe
echo ============================================================
pause
