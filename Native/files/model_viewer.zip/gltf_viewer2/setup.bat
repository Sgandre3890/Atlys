@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo  Model Viewer - Windows Setup (MinGW / MSYS2, no VS needed)
echo ============================================================
echo.

:: ── Check for MSYS2 ──────────────────────────────────────────────────────────
:: MSYS2 gives us GCC + pacman (package manager) without needing Visual Studio.

set MSYS2_DIR=C:\msys64

if not exist "%MSYS2_DIR%\usr\bin\bash.exe" (
    echo [ERROR] MSYS2 not found at %MSYS2_DIR%
    echo.
    echo  Please install MSYS2 first:
    echo    1. Go to https://www.msys2.org/
    echo    2. Download and run the installer
    echo    3. Use the default install path  ^(C:\msys64^)
    echo    4. Re-run this script
    echo.
    pause & exit /b 1
)
echo [OK] MSYS2 found at %MSYS2_DIR%

:: ── Install all dependencies via pacman in one shot ───────────────────────────
echo.
echo [INFO] Installing compiler and dependencies via pacman...
echo        ^(This may take a few minutes the first time^)
echo.

%MSYS2_DIR%\usr\bin\bash.exe -lc ^
  "pacman -S --noconfirm --needed mingw-w64-x86_64-gcc mingw-w64-x86_64-cmake mingw-w64-x86_64-ninja mingw-w64-x86_64-glfw mingw-w64-x86_64-glm mingw-w64-x86_64-assimp mingw-w64-x86_64-git"

if errorlevel 1 (
    echo [ERROR] pacman install failed. Make sure MSYS2 is properly installed.
    pause & exit /b 1
)
echo.
echo [OK] All packages installed

:: ── Download stb_image ────────────────────────────────────────────────────────

if not exist "stb_image.h" (
    echo [INFO] Downloading stb_image.h...
    %MSYS2_DIR%\usr\bin\bash.exe -lc ^
      "curl -sL https://raw.githubusercontent.com/nothings/stb/master/stb_image.h -o '%~dp0stb_image.h'"
    if not exist "stb_image.h" (
        echo [ERROR] Failed to download stb_image.h
        pause & exit /b 1
    )
    echo [OK] stb_image.h downloaded
)

:: ── Build using MinGW CMake ────────────────────────────────────────────────────
:: We call CMake from inside MSYS2 so it finds the MinGW compiler automatically.

echo.
echo [INFO] Configuring and building...
echo.

set SOURCE_DIR=%~dp0
:: Convert Windows path to Unix-style for MSYS2
set SOURCE_UNIX=%SOURCE_DIR:\=/%
set SOURCE_UNIX=%SOURCE_UNIX:C:=/c%

%MSYS2_DIR%\usr\bin\bash.exe -lc ^
  "export PATH=/mingw64/bin:$PATH && cd '%SOURCE_UNIX%' && rm -rf build && mkdir build && cd build && cmake .. -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH='/mingw64' && ninja"

if errorlevel 1 (
    echo.
    echo [ERROR] Build failed. Check the output above for details.
    pause & exit /b 1
)

echo.
echo ============================================================
echo  Success^^!  Run model_viewer.exe to start.
echo ============================================================
pause
