#ifndef __khrplatform_h_
#define __khrplatform_h_
typedef          float  khronos_float_t;
typedef signed   char   khronos_int8_t;
typedef unsigned char   khronos_uint8_t;
typedef signed   short  khronos_int16_t;
typedef unsigned short  khronos_uint16_t;
#if defined(_WIN64) || defined(__LP64__)
typedef signed   long long int khronos_intptr_t;
typedef unsigned long long int khronos_uintptr_t;
typedef signed   long long int khronos_ssize_t;
typedef unsigned long long int khronos_usize_t;
#else
typedef signed   long int khronos_intptr_t;
typedef unsigned long int khronos_uintptr_t;
typedef signed   long int khronos_ssize_t;
typedef unsigned long int khronos_usize_t;
#endif
typedef signed   long long int khronos_int64_t;
typedef unsigned long long int khronos_uint64_t;
typedef signed   int  khronos_int32_t;
typedef unsigned int  khronos_uint32_t;
#define KHRONOS_SUPPORT_INT64 1
#define KHRONOS_SUPPORT_FLOAT 1
#if defined(__SCITECH_SNAP__) && !defined(KHRONOS_STATIC)
#   define KHRONOS_STATIC
#endif
#if defined(KHRONOS_STATIC)
#   define KHRONOS_APICALL
#elif defined(_WIN32)
#   define KHRONOS_APICALL __declspec(dllimport)
#elif defined (__SYMBIAN32__)
#   define KHRONOS_APICALL IMPORT_C
#elif defined(__ANDROID__)
#   define KHRONOS_APICALL __attribute__((visibility("default")))
#else
#   define KHRONOS_APICALL
#endif
#if defined(_WIN32) && !defined(_WIN32_WCE) && !defined(__SCITECH_SNAP__)
#   define KHRONOS_APIENTRY __stdcall
#else
#   define KHRONOS_APIENTRY
#endif
#if defined(__SCITECH_SNAP__)
#   define KHRONOS_APIATTRIBUTES
#else
#   define KHRONOS_APIATTRIBUTES
#endif
#define KHRONOS_FALSE  0
#define KHRONOS_TRUE   1
typedef int khronos_boolean_enum_t;
#endif /* __khrplatform_h_ */
